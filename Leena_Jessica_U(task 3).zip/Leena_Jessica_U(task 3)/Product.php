<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'image',
        'name',
        'description',
        'selling_price',
        'gst',
        'buying_price',
        'profit_percentage',
    ];

    // ... You can add any additional model code, relationships, etc.
}
