<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function index()
    {
        $products = Product::all();
        return view('home', ['products' => $products]);
    }

    public function create()
    {
        return view('add-product');
    }

    public function store(Request $request)
    {
        $request->validate([
            'productImage' => 'required|url',
            'productName' => 'required|string',
            'productDescription' => 'required|string',
            'productImage' => 'required|url',
            'productSellingPrice' => 'required|numeric',
            'productGST' => 'required|numeric',
            'productBuyingPrice' => 'required|numeric',
            'productProfitPercentage' => 'required|numeric',
        ]);

        $product = new Product([
            'image' => $request->input('productImage'),
            'name' => $request->input('productName'),
            'description' => $request->input('productDescription'),
            'selling_price' => $request->input('productSellingPrice'),
            'gst' => $request->input('productGST'),
            'buying_price' => $request->input('productBuyingPrice'),
            'profit_percentage' => $request->input('productProfitPercentage'),
        ]);

        $product->save();

        return redirect('/')->with('success', 'Product added successfully!');
    }

    public function show($id)
    {
        $product = Product::find($id);
        return view('product-details', ['product' => $product]);
    }
}
