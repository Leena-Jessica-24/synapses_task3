
@extends('layouts.app')

@section('title', 'Home')

@section('content')
<style>
    section {
        text-align: center;
        margin: 20px;
    }

    h2 {
        color: #333;
    }

    .slideshow-container {
        max-width: 100%;
        position: relative;
        margin: auto;
        max-height: 300px;
    }

    .mySlides {
        display: none;
        width: 100%;
        max-height: 300px; 
    }

    img.product-image {
        width: 10%;
        height: auto;
        max-height: 200px;
        margin-bottom: 10px;
    }

    .product-list {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        align-items: flex-start;
    }

    .product-item {
        flex-basis: calc(33.33% - 20px);
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        margin: 10px 0;
        padding: 15px;
        transition: background-color 0.3s ease;
    }

    .product-name {
        color: #333;
        font-size: 1.2em;
    }

    .product-description {
        color: #666;
    }

    .product-price, .product-gst, .product-buying-price, .product-profit-percentage {
        color: #555;
        margin: 5px 0;
    }

    .view-details-btn, .add-product-btn {
        display: inline-block;
        padding: 10px 20px;
        margin-top: 10px;
        text-decoration: none;
        color: #fff;
        background-color: #007bff;
        border: 1px solid #007bff;
        border-radius: 5px;
        transition: background-color 0.3s ease, border-color 0.3s ease;
    }

    .view-details-btn:hover, .add-product-btn:hover {
        background-color: #0056b3;
        border-color: #0056b3;
    }

    .no-products {
        color: #999;
    }
</style>

<section id="home">
    <h2>Product List</h2>

    <div class="slideshow-container">
        
        <div class="mySlides">
            <img src="{{ asset('images/slide1.jpg') }}" alt="Slide 1" class="product-image">
        </div>
        <div class="mySlides">
            <img src="{{ asset('images/slide22.jpg') }}" alt="Slide 2" class="product-image">
        </div>
        <div class="mySlides">
            <img src="{{ asset('images/slide3.jpg') }}" alt="Slide 3" class="product-image">
        </div>
    </div>

    <div class="product-list">
        @if(count($products) > 0)
            @foreach($products as $product)
                <div class="product-item">
                    <img src="{{ $product->image }}" alt="{{ $product->name }}" class="product-image"><br>
                    <strong class="product-name">{{ $product->name }}</strong>
                    <p class="product-description">{{ $product->description }}</p>
                    <p class="product-price">Selling Price: ${{ $product->selling_price }}</p>
                    <p class="product-gst">GST: {{ $product->gst }}%</p>
                    <p class="product-buying-price">Buying Price: ${{ $product->buying_price }}</p>
                    <p class="product-profit-percentage">Profit Percentage: {{ $product->profit_percentage }}%</p>
                    <a href="{{ url("/product/{$product->id}") }}" class="view-details-btn">View Details</a>
                </div>
            @endforeach
        @else
            <p class="no-products">No products available.</p>
        @endif
    </div>

    <a href="{{ url('/add-product') }}" class="add-product-btn">Add New Product</a>

</section>

<script>
    let slideIndex = 0;
    showSlides();

    function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1;
        }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 3000); 
    }
</script>
@endsection
