@extends('layouts.app')

@section('title', 'Add New Product')

@section('content')
    <style>
        .add-product-section {
            text-align: center;
            margin: 20px;
        }

        h2 {
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
        }

        .form-control {
            width: 40%; /* Reduced width */
            padding: 10px;
            box-sizing: border-box;
            border: 1px solid #ccc; /* Lighter border color */
            border-radius: 5px;
            margin-bottom: 2px;
            font-size: 14px; /* Adjusted font size */
            color: #333; /* Adjusted font color */
        }

        .add-product-btn, .return-home-btn {
            display: inline-block;
            padding: 12px 24px; /* Increased padding */
            text-decoration: none;
            color: #fff;
            background-color: #28a745; /* Updated background color */
            border: 1px solid #28a745; /* Updated border color */
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
            margin-right: 10px;
        }

        .add-product-btn:hover, .return-home-btn:hover {
            background-color: #218838; /* Darker hover color */
            border-color: #218838; /* Darker hover color */
        }
    </style>

    <section id="addProduct" class="add-product-section">
        <h2>Add New Product</h2>
        <form id="productForm">


            <div class="form-group">
                <label for="productImageFile">Upload Product Image:</label>
                <input type="file" id="productImageFile" class="form-control-file" accept="image/*">
            </div>
            
            <div class="form-group">
                <label for="productName">Product Name:</label>
                <input type="text" id="productName" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="productDescription">Product Description:</label>
                <textarea id="productDescription" class="form-control" required></textarea>
            </div>

            <div class="form-group">
                <label for="productImage">Product Image URL:</label>
                <input type="text" id="productImage" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="productSellingPrice">Selling Price:</label>
                <input type="number" id="productSellingPrice" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="productGST">GST:</label>
                <input type="number" id="productGST" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="productBuyingPrice">Buying Price:</label>
                <input type="number" id="productBuyingPrice" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="productProfitPercentage">Profit Percentage:</label>
                <input type="number" id="productProfitPercentage" class="form-control" required>
            </div>

            <button type="button" onclick="addProduct()" class="add-product-btn">Add Product</button>
            <a href="{{ url('/') }}" class="return-home-btn">Return to Home Page</a>
        </form>
    </section>
@endsection
