<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description');
            $table->string('image'); // Making image column nullable
            $table->decimal('selling_price', 10, 2);
            $table->decimal('gst', 5, 2); // Adding a default value for GST
            $table->decimal('buying_price', 10, 2);
            $table->decimal('profit_percentage', 5, 2);
            $table->timestamps();

            // Adding unique constraint on the name column
            $table->unique('name');
        });
    }

    public function down()
    {
        Schema::dropIfExists('products');
    }
}
