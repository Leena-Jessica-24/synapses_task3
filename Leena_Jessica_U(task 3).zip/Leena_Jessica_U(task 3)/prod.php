<!-- resources/views/product-details.blade.php -->

@extends('layouts.app')

@section('title', 'Product Details')

@section('content')
    <style>
        #productDetails {
            text-align: center;
            margin: 20px;
            background-color: #f4f4f4; /* Set your desired background color */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #333;
        }

        .product-info {
            margin-top: 20px;
            padding: 20px;
            background-color: #ffffff; /* Set the background color for the product info */
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        img {
            max-width: 100%;
            height: auto;
            margin-bottom: 20px;
        }

        p {
            color: #555;
            margin: 10px 0;
        }

        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            border: 1px solid #007bff;
            border-radius: 5px;
            transition: background-color 0.3s ease, border-color 0.3s ease;
            margin-top: 20px;
        }

        .back-btn:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
    </style>

    <section id="productDetails">
        @if(isset($product))
            <h2>{{ $product->name }}</h2>

            <div class="product-info">
                <img src="{{ $product->image }}" alt="{{ $product->name }}">
                <p>Description: {{ $product->description }}</p>
                <p>Selling Price: ${{ $product->selling_price }}</p>
                <p>GST: {{ $product->gst }}%</p>
                <p>Buying Price: ${{ $product->buying_price }}</p>
                <p>Profit Percentage: {{ $product->profit_percentage }}%</p>
                <!-- Add more details as needed -->
            </div>

            <a href="{{ url('/') }}" class="back-btn">Back to Products</a>
        @else
            <p>Product not found.</p>
        @endif
    </section>
@endsection
